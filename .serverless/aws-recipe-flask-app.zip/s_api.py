import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='hyunsung9898',
    application_name='aws-recipe-flask-app',
    app_uid='Z50tbfX3vF19WgQ52m',
    org_uid='49aecc6b-4e81-484c-ba93-760a26b95e3f',
    deployment_uid='6b93e5b0-c71e-41ca-b750-41d4885e12be',
    service_name='aws-recipe-flask-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-recipe-flask-app-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
